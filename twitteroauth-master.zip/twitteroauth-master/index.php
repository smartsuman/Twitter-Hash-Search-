<?php
//namespace Abraham\TwitterOAuth;
require_once 'autoload.php';

use Abraham\TwitterOAuth\TwitterOAuth;

// echo "Hi";die;
define('CONSUMER_KEY', 'W1hmjsrwzG20NHDKLPDOywbX8');
define('CONSUMER_SECRET', 'tGU3ixqkhQ1UwiZOHHTY2rOWg3o09jE5QkWkTqKDvrIhUDthLI');
define('ACCESS_TOKEN', '476664408-QMwRy3bW26VHj3jjWTi6AKWPdPc7z9iTAGHTjB6M');
define('ACCESS_TOKEN_SECRET', 's3Tiy8sECHcskzvmp8KJzn9HJnUvV6izA69KdvtcSHEro');

function search(array $query) {
    $toa = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET);
    return $toa->get('search/tweets', $query);
}


?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
     Search: <input type="text" value="<?php echo$_POST['Search']; ?>" name="Search"><br>
        <input type="submit">
    </form>
<?php
if (!empty($_POST)):
    $query = array(
    "q" => $_POST['Search'],
);

$results = search($query);

echo "<b>Search text : </b>".$_POST['Search']."<br>";
echo "<b>no of tweets : </b>".  count($results->statuses)."<br>";
    foreach ($results->statuses as $result) {
        echo $result->user->screen_name . ": " . $result->text . "\n<br><br><br>";
    }
    ?>

   
<?php endif; ?>
 